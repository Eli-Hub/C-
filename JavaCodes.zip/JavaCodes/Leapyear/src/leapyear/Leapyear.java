/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
//
package leapyear;
import java.util.Scanner;

//public class Leapyear {
//	public static void main (String [ ] args) {
//	String phrase = "GTUC is in Accra";
//	String mutation1, mutation2, mutation3, mutation4;
//	System.out.println ("Original string: \"" + phrase + "\"");
//	System.out.println ("Length of string:" + phrase.length());
//mutation1 = phrase.concat (", and also in Kumasi, Ho etc.");
//mutation2 = mutation1.toUpperCase();
//mutation3 = mutation2.substring(3, 30);
//mutation4 = mutation3.replace('C', 'K');
//	System.out.println ("First mutation: " + mutation1);
//	System.out.println ("Second mutation: " + mutation2);
//	System.out.println ("Third mutation: " + mutation3);
//        System.out.println ("Fourth mutation: " + mutation4);
//        }
//}



public class Leapyear {

   
    public static void main(String[] args) {
        Scanner accept = new Scanner (System.in);
        
       int year=0;
       System.out.println("Enter Year: ");
       
       year = accept.nextInt();
       if (year%4 == 0 || year%100 == 0 && year%400 == 0){
           
           System.out.println(year + " is a leap year.");
       }
       
       else
       {
           System.out.println(year + " is not a leap year.");
       }
    }
    
}

//MULTIPLICATION
//public class Leapyear {
//
//public static void main(String[] args) {
//
//System.out.println("  ");
//System.out.println("   Multiplication Table");
//System.out.println(" ");
//System.out.print("   ");
//
//for (int m=1; m<=9; m++)
//System.out.print("  " + m);
//System.out.println(" ");
//System.out.println("-------------------------------  ");
//	for (int s=1; s<=9; s++)
//	{
//	System.out.print(s + " |");
//		for (int m=1; m<=9; m++)
//		{
//		if (m*s < 10)
//		System.out.print("  " + m*s);
//		else
//		System.out.print(" " + m*s);
//		}
//System.out.println();
//}}}