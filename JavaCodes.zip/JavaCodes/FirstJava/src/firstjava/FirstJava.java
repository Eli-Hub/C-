/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package firstjava;

/**
 *
 * @author E m m a n u e l
 */
public class FirstJava {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        System.out.print("\t \t \t \t MYSELF \n Emmanuel Hodo is my name. I am 25 years of age with dark complexion."
                + "\n I have big round eyes with dark pupil and a broad face with a well endowed nose."
                + "\n "
                + " \n I had my second cycle education at St. Paul's Senior High School with a Business Programme. "
                + " \n Currently I am persuing my HND in ICT in Ho Technical University. My areas of specialization are "
                + " \n Research Analysis, Web Programming and Networking. \n"
                + "\n I hail from Have in the Volta Region of Ghana. I come from a family of four. My dad is a retired teacher "
                + "\n and my mum a petty trader. My younger sister is married with two kids currently at Aflao. \n"
                + "\n I enjoy watching movies and listening to music at my leisure time. My favourite food is rice with vegetable stew.");
        // TODO code application logic here
    }
    
}
