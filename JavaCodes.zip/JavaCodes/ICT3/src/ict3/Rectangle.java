/*
SUPER CLASS
 */
package ict3;

/**
 *
 * @author E m m a n u e l
 */
public class Rectangle {
	protected int length;
	protected int width;

	public Rectangle (int l, int w) {
	
	length = l; width = w;

	}

	public int Area() {

	return length*width;

	}

}
