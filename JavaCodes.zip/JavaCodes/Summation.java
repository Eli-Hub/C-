class Summation {

public static void main (String args[]) {

int num=0;

java.util.Scanner hello = new java.util.Scanner (System.in);

	for (int i = 1; i<=10; i++) {

	num = num+i;	
}

System.out.print ("Sum of Integers from 1 to 10 = " + num);

num=0;
	for (int i = 20; i<=37; i++) {

	num = num+i;

}

System.out.print ("\n Sum of Integers from 20 to 37= " + num);

num=0;

System.out.print ("Sum of Integers from 1 to 10 = " + num);

num=0;
	for (int i = 20; i<=37; i++) {

	num = num+i;

}

System.out.print ("\n Sum of Integers from 20 to 37= " + num);

num=0;
}
}