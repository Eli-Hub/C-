public class Myselfmaclean{

    public static void main(String []args){
	System.out.print("MySelf."
	 + "\n My name is Maclean Sallah Ewoenam Kofi.I am 21 years old and i am a boy."
 	+ "I am a Ghanain born in the city Dambai with volta decent,i was born into the family of Mr and Mrs Sallah." 
 	+ "I live a sheltered life.I live with my mom mostly,but i get lots of attention from both parents."
 	+ "I am a Graphic Designer,Digital artist,Photographer and IT personel, I love to cook, discover new cultures plus great lover of art."
 	+ "I love meeting people and i love making friends with people who are social."
 	+ "I am who i am,and i make no excuses for how i have turned out.");
}
}