class Test{

public static void main (String args[]) {

int Sum=0;

	for (int i = 1; i<=10; i++) {

	Sum+ =i;	
}

System.out.print (" Sum ="+ Sum);
sum = 0
	for (int i = 20; i<=37; i++)
	Sum+ =i;


}
System.out.print (" Sum ="+Sum);


}
}