public class myproject{

           public static void main(String [] args) {
             System.out.print("MYSELF" +
"My name is Morladza Festus Yao a student of Ho Technical University offering HND in Information and Communication Technology." +
"I am dark in complexion with an age of 20years and I like sports. My favourite sport is Basketball and Athletes" +
"and I love banku with okro soup. I attended Aflao Border Junior High School and Three-Town Senior High School." +
"I am from Aflao in the Ketu South of Volta Region, a town full of lots of hustlers." +
"A good graphics designer with much knowledge in Photoshop, Adobe Aftereffect, Illustrator, Website designs and others." +
"I love using my leisure time doing something meaningful that will benefit or bring good incomes to my pocket." +
"I love being with my good friends who always talks about business, how to survive and how make some choices in life");
      }
}