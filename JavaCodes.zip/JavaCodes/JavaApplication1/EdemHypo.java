class EdemHypo{
public static void main(String[]args){
int base=14, height=18;
double hypo;
hypo = Math.sqrt(Math.pow(base,2)+Math.pow(height,2));
system.out.println("Hypotenuse ="+ hypo);
system.out.println("Hypotenuse ="+ (int) hypo);




}







}