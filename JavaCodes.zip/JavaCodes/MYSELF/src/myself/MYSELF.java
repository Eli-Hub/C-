/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package myself;

/**
 *
 * @author E m m a n u e l
 */
public class MYSELF {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        
        System.out.print("\t \t \t \t MYSELF \n My name is Gifty Rita Buadu, the first daughter of my parents."
                + "\n I hail from a village called Awudome Avenui in the volta region of Ghana.."
                + "\n "
                + " \n I am fair in complexion and 5.5 feet tall. "
                + " \n I am 25 years of age. "
                + " \n I had both my primary and junior secondary education Avenui."
                + " \n  And later moved to Kpedze for my secondary education."
                + " \n  I am currently studying Information Communication and Technology in Ho Technical University. "
                + "\n I love reading, listening to music and staying indoors most at times."
                + "\n My favorite food is banku with okra stew. My favorite colour is white and pink.");
        // TODO code application logic here
    }
    
}
