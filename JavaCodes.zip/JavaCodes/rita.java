class loan{

public static void main (Strings []args){

double principal = 0, rate = 0.1, interest = 0.40;
int time = 1.5;
double interest = principal*time*rate/100;

System.out.println ( " Your loan of"+principal+cedis"+" at a rate of "rate"% per annum, and "+" over a period of "time" year has an interest "+" of "+interest+"cedis);  












}






}