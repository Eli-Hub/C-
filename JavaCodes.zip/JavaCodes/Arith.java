public class Arith {
	public static void main (String [] args ) {
	
		double a = 7.9, b = 3.2;
		double hypo = Math.sqrt(Math.pow(a, 2) + Math.pow(b,2));
		System.out.print ("\n Opposite = " + a + "\n \n Adjacent = " + b + "\n \n Hypotanous = "+ (int) hypo);
}
} 