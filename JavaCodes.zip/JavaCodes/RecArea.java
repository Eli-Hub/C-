public class RecArea{


public static void main (String []args){

	int L = 37, B = 20;
	int area = L * B ;
	System.out.println ("The length of the rectangle = " + L + "\n The breadth of the rectangle = " + B + "\n The area of the rectangle = " + area);
	

}



}