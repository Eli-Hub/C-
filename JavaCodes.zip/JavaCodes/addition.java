public class addition{

public static void main (String []args){

	int num1 = 25, num = 12;
	
	System.out.println ("Your answer = "+ (num1 + num));




}

}

