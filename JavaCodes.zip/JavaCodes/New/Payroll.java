import java.util.Scanner; 
import java.text.NumberFormat;

class Payroll {
        private double Basic_Salary;
        private double Tax_Relief;

        
    Payroll ()
    {
    Basic_Salary = 0.00;
    Tax_Relief = 0.00;
    }

    public Payroll(double Bs, double Tr)
    {
    Basic_Salary = Bs;
    Tax_Relief = Tr;
    }

    public double getSSNIT()
    {
    return 0.05 * Basic_Salary;
    }

    public double getTaxableIncome()
    {
    return Basic_Salary - (getSSNIT() + Tax_Relief);
    }

    public double getIncomeTax()
    {
    double IncomeTax = 0.0;
    if (getTaxableIncome()>0 && getTaxableIncome()<=100){
    IncomeTax = 0.0 * getTaxableIncome();
    }
    else if  (getTaxableIncome()>100 && getTaxableIncome() <=500){
    IncomeTax = 0.98 * getTaxableIncome();
    }
    else{
    IncomeTax = 0.175 * getTaxableIncome();
    }
    return IncomeTax;
    }

    public double getTotalDeduction(){
    return getSSNIT() + Tax_Relief;
    }

    public double getNetIncome(){
    return Basic_Salary - getTotalDeduction();
    }


        public static void main(String[]args){



        Scanner input = new Scanner(System.in);
        double Basic_Salary;
        double Tax_Relief;

        NumberFormat currency = NumberFormat.getCurrencyInstance();


        System.out.println("ENTER YOUR BASIC SALARY PLEASE !!!");
          Basic_Salary  = input.nextDouble();

        System.out.println("ENTER YOUR TAX RELIEF PLEASE !!!");
          Tax_Relief  = input.nextDouble();

         Payroll staff=new Payroll(Basic_Salary,Tax_Relief) ;

        System.out.println("Basic Salary is : " + currency.format(staff.Basic_Salary));
        System.out.println("Tax Relief is : " + currency.format(staff.Tax_Relief));
        System.out.println("SSNIT is : " + currency.format(staff.getSSNIT()));
        System.out.println("Taxable income is : " + currency.format(staff.getTaxableIncome()));
        System.out.println("Income tax is : " + currency.format(staff.getIncomeTax()));
        System.out.println("Total deduction is : " + currency.format(staff.getTotalDeduction()));
        System.out.println("Net Income is : " + currency.format(staff.getNetIncome()));
        }

}