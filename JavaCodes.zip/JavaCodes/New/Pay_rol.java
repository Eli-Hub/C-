import java.util.Scanner; 

public class Pay_rol {
public static void main(String[]args){

Payrrol staff=new Payrrol() ;

Scanner input = new Scanner(System.in);
double Basic_Salary;
double Tax_Relief;

System.out.println("ENTER YOUR BASIC SALARY PLEASE !!!");
  Basic_Salary  = input.nextDouble();

System.out.println("ENTER YOUR TAX RELIEF PLEASE !!!");
  Tax_Relief  = input.nextDouble();

System.out.println("Basic Salary is : " + staff.Basic_Salary);
System.out.println("Tax Relief is : " + staff.Tax_Relief);
System.out.println("SSNIT is : " + staff.getSSNIT());
System.out.println("Taxable income is : " + staff.getTaxableIncome());
System.out.println("Income tax is : " + staff.getIncomeTax());
System.out.println("Total deduction is : " + staff.getTotalDeduction());
}

}

