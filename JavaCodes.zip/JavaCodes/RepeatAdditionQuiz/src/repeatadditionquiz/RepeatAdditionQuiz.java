
package repeatadditionquiz;

//import java.util.Scanner;
import java.util.*;
import java.text.DecimalFormat;
public class RepeatAdditionQuiz {

   
    public static void main(String[] args) {
//       
//        String name = "me";
//        System.out.print(name);
//         Scanner INPUT = new Scanner(System.in);
//         
//        int num1 = (int)(Math.random()*5);
//        int num2 = (int)(Math.random()*10);
//        int answer;
//      
//        System.out.println("What is "+ num1 +" + "+ num2 + " ?");
//        answer = INPUT.nextInt();
// 
//      
//      while (num1+num2 != answer){
//
//            System.out.println("Wrong answer. Try Again. What is "+ num1 +" + "+ num2 + " ?");
//             answer = INPUT.nextInt();
//
//            
//      }
//   
//      
//      System.out.println("You got it.");

        
//        int [] myList = new int [9];
//        double ans = 78.2548;
//        DecimalFormat num = new DecimalFormat("0.00");
//        System.out.println ("Enter num "+ num.format(ans));
//        Scanner num = new Scanner (System.in);
//        for (int i=0; i<=myList.length; i++){
//        System.out.println ("Enter num "+ (i+1)+ " : ");
//                myList[i] = num.nextInt();
//                
//                }    
// 
//        System.out.println ("Numbers entered include: "+ myList);
        
        
        Random generator = new Random();
	int num1;
	float num2;
	num1 = generator.nextInt();
	System.out.println ("A random integer: " + num1);
	num1 = generator.nextInt(10) + 1;
	System.out.println ("From 1 to 10: " + num1);
	num2 = generator.nextFloat();
	System.out.println ("A random float: " + num2);

        
        
        
                }
    
        
        
}
